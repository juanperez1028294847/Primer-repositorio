let destinos = [
  {nombre: "Torre Eiffel", descripcion: "El monumento más famoso de París.", precio: 1200, disponible: true, proveedor: "Viajes París", imagen: "https://1.bp.blogspot.com/-XCDP_qtL724/UQgMmYegCuI/AAAAAAAAjdE/hmq_X36t-Hs/s1600/202_1la_tour_eiffel___paris__france.jpg"},
  {nombre: "Playa de Cancún", descripcion: "Hermosas playas en México.", precio: 1500, disponible: true, proveedor: "Cancún Travel", imagen: "https://tse3.mm.bing.net/th/id/OIP.DRYUnrL48XV5bCs3UYhjbAHaEo"},
  {nombre: "Machu Picchu", descripcion: "La famosa ciudadela inca en Perú.", precio: 1800, disponible: false, proveedor: "Andes Tours", imagen: "https://th.bing.com/th/id/R.66d31ce4f566a57095ae7ee2efee6969?rik=zfT7Ka2O3pbWDg&pid=ImgRaw&r=0"}
];

let proveedores = [
  {nombre: "Viajes París", pais: "Francia"},
  {nombre: "Cancún Travel", pais: "México"},
  {nombre: "Andes Tours", pais: "Perú"}
];

function renderDestinos() {
  const lista = document.getElementById("destinos-list");
  lista.innerHTML = "";
  destinos.forEach(d => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <img src="${d.imagen}" alt="${d.nombre}">
      <h3>${d.nombre}</h3>
      <p>${d.descripcion}</p>
      <p><b>Precio:</b> $${d.precio}</p>
      <p><b>Estado:</b> ${d.disponible ? "Disponible" : "No disponible"}</p>
      <p><b>Proveedor:</b> ${d.proveedor || "Sin proveedor"}</p>
    `;
    lista.appendChild(card);
  });
}

function renderProveedores() {
  const select = document.getElementById("proveedor-destino");
  select.innerHTML = "<option value=''>-- Sin proveedor --</option>";
  proveedores.forEach(p => {
    const option = document.createElement("option");
    option.value = p.nombre;
    option.textContent = p.nombre;
    select.appendChild(option);
  });
}

function agregarDestino() {
  const nombre = document.getElementById("nombre-destino").value;
  const descripcion = document.getElementById("descripcion-destino").value;
  const precio = document.getElementById("precio-destino").value;
  const disponible = document.getElementById("disponible-destino").checked;
  const proveedor = document.getElementById("proveedor-destino").value;
  const imagen = document.getElementById("imagen-destino").value || "https://via.placeholder.com/400x250?text=Destino";

  if (!nombre || !descripcion || !precio) {
    alert("Por favor completa todos los campos.");
    return;
  }

  destinos.push({nombre, descripcion, precio, disponible, proveedor, imagen});
  renderDestinos();
}

function agregarProveedor() {
  const nombre = document.getElementById("nombre-proveedor").value;
  const pais = document.getElementById("pais-proveedor").value;

  if (!nombre || !pais) {
    alert("Por favor completa todos los campos.");
    return;
  }

  proveedores.push({nombre, pais});
  renderProveedores();
}

window.onload = () => {
  renderDestinos();
  renderProveedores();
};
