import { IsString, IsNumber, IsBoolean, IsOptional } from 'class-validator';

export class CreateDestinoDto {
  @IsString()
  nombre: string;

  @IsString()
  descripcion: string;

  @IsNumber()
  precio: number;

  @IsBoolean()
  disponible: boolean;

  @IsOptional()
  @IsNumber()
  proveedorId?: number;
}