import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { DestinosService } from './destinos.service';
import { CreateDestinoDto } from './dto/create-destino.dto';

@Controller('destinos')
export class DestinosController {
  constructor(private readonly destinosService: DestinosService) {}

  @Get()
  findAll() {
    return this.destinosService.findAll();
  }

  @Post()
  create(@Body() createDestinoDto: CreateDestinoDto) {
    return this.destinosService.create(createDestinoDto);
  }

  @Get(':id/proveedor')
  getProveedor(@Param('id') id: string) {
    return this.destinosService.getProveedor(+id);
  }
}