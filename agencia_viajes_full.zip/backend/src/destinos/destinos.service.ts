import { Injectable } from '@nestjs/common';
import { CreateDestinoDto } from './dto/create-destino.dto';
import { ProveedoresService } from '../proveedores/proveedores.service';

@Injectable()
export class DestinosService {
  private destinos = [
    { id: 1, nombre: 'Cancún', descripcion: 'Playa paradisíaca', precio: 500, disponible: true, proveedorId: 1 },
    { id: 2, nombre: 'París', descripcion: 'Ciudad de la luz', precio: 1200, disponible: false, proveedorId: 2 },
  ];

  constructor(private readonly proveedoresService: ProveedoresService) {}

  findAll() {
    return this.destinos;
  }

  create(dto: CreateDestinoDto) {
    const nuevo = { id: this.destinos.length + 1, ...dto };
    this.destinos.push(nuevo);
    return nuevo;
  }

  getProveedor(id: number) {
    const destino = this.destinos.find(d => d.id === id);
    if (destino?.proveedorId) {
      return this.proveedoresService.findOne(destino.proveedorId);
    }
    return null;
  }
}