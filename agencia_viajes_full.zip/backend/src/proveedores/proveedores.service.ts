import { Injectable } from '@nestjs/common';
import { CreateProveedorDto } from './dto/create-proveedor.dto';

@Injectable()
export class ProveedoresService {
  private proveedores = [
    { id: 1, nombre: 'BestTravel', pais: 'México' },
    { id: 2, nombre: 'EuroTours', pais: 'Francia' },
  ];

  findAll() {
    return this.proveedores;
  }

  create(dto: CreateProveedorDto) {
    const nuevo = { id: this.proveedores.length + 1, ...dto };
    this.proveedores.push(nuevo);
    return nuevo;
  }

  findOne(id: number) {
    return this.proveedores.find(p => p.id === id);
  }
}