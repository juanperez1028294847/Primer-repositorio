import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DestinosService } from '../services/destinos.service';

@Component({
  selector: 'app-destinos',
  templateUrl: './destinos.component.html'
})
export class DestinosComponent {
  destinos: any[] = [];
  form: FormGroup;
  selectedImage: string | ArrayBuffer | null = null;

  constructor(private fb: FormBuilder, private destinosService: DestinosService) {
    this.form = this.fb.group({
      nombre: ['', Validators.required],
      descripcion: ['', Validators.required],
      precio: ['', Validators.required],
      disponible: [true],
      proveedorId: ['']
    });
    this.loadDestinos();
  }

  loadDestinos() {
    this.destinosService.getDestinos().subscribe(data => this.destinos = data);
  }

  submit() {
    this.destinosService.addDestino(this.form.value).subscribe(() => this.loadDestinos());
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = e => this.selectedImage = reader.result;
      reader.readAsDataURL(file);
    }
  }
}