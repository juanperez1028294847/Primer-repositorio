import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class DestinosService {
  private api = 'http://localhost:3000/destinos';

  constructor(private http: HttpClient) {}

  getDestinos(): Observable<any[]> {
    return this.http.get<any[]>(this.api);
  }

  addDestino(destino: any): Observable<any> {
    return this.http.post<any>(this.api, destino);
  }
}