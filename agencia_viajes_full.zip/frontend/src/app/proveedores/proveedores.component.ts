import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProveedoresService } from '../services/proveedores.service';

@Component({
  selector: 'app-proveedores',
  templateUrl: './proveedores.component.html'
})
export class ProveedoresComponent {
  proveedores: any[] = [];
  form: FormGroup;

  constructor(private fb: FormBuilder, private proveedoresService: ProveedoresService) {
    this.form = this.fb.group({
      nombre: ['', Validators.required],
      pais: ['', Validators.required]
    });
    this.loadProveedores();
  }

  loadProveedores() {
    this.proveedoresService.getProveedores().subscribe(data => this.proveedores = data);
  }

  submit() {
    this.proveedoresService.addProveedor(this.form.value).subscribe(() => this.loadProveedores());
  }
}