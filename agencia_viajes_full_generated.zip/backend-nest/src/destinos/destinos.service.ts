import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateDestinoDto } from './dto/create-destino.dto';
import { ProveedoresService } from '../proveedores/proveedores.service';

export type Destino = {
  id: number;
  nombre: string;
  descripcion?: string;
  precio: number;
  disponible: boolean;
  proveedorId?: number;
};

@Injectable()
export class DestinosService {
  private destinos: Destino[] = [];
  private idCounter = 1;

  constructor(private readonly proveedoresService: ProveedoresService) {
    this.create({ nombre: 'Playa Paraíso', descripcion: 'Arena blanca', precio: 200, disponible: true });
    this.create({ nombre: 'Cañón Aventura', descripcion: 'Trekking', precio: 150, disponible: false });
    const provs = this.proveedoresService.findAll();
    if (provs.length > 0) {
      this.create({ nombre: 'Isla Misterio', descripcion: 'Snorkel', precio: 300, disponible: true, proveedorId: provs[0].id });
    }
  }

  findAll(): Destino[] {
    return this.destinos;
  }

  create(dto: CreateDestinoDto): Destino {
    if (dto.proveedorId !== undefined) {
      this.proveedoresService.findOne(dto.proveedorId);
    }
    const d: Destino = { id: this.idCounter++, ...dto };
    this.destinos.push(d);
    return d;
  }

  findOne(id: number): Destino {
    const d = this.destinos.find(x => x.id === id);
    if (!d) throw new NotFoundException(`Destino ${id} no encontrado`);
    return d;
  }

  findProveedorOfDestino(id: number) {
    const destino = this.findOne(id);
    if (!destino.proveedorId) return null;
    return this.proveedoresService.findOne(destino.proveedorId);
  }
}
