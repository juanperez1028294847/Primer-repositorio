export class DestinoResponseDto {
  id: number;
  nombre: string;
  descripcion?: string;
  precio: number;
  disponible: boolean;
  proveedorId?: number;
}
