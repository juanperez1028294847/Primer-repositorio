import { Body, Controller, Get, Param, Post, ParseIntPipe } from '@nestjs/common';
import { DestinosService } from './destinos.service';
import { CreateDestinoDto } from './dto/create-destino.dto';

@Controller('destinos')
export class DestinosController {
  constructor(private readonly destinosService: DestinosService) {}

  @Get()
  getAll() {
    return this.destinosService.findAll();
  }

  @Post()
  create(@Body() dto: CreateDestinoDto) {
    return this.destinosService.create(dto);
  }

  @Get(':id')
  getOne(@Param('id', ParseIntPipe) id: number) {
    return this.destinosService.findOne(id);
  }

  @Get(':id/proveedor')
  getProveedor(@Param('id', ParseIntPipe) id: number) {
    return this.destinosService.findProveedorOfDestino(id);
  }
}
