import { Injectable, NotFoundException } from '@nestjs/common';
import { CreateProveedorDto } from './dto/create-proveedor.dto';

export type Proveedor = {
  id: number;
  nombre: string;
  pais: string;
};

@Injectable()
export class ProveedoresService {
  private proveedores: Proveedor[] = [];
  private idCounter = 1;

  constructor() {
    this.create({ nombre: 'Sol Travels', pais: 'España' });
    this.create({ nombre: 'Aventura S.A.', pais: 'México' });
  }

  findAll(): Proveedor[] {
    return this.proveedores;
  }

  create(dto: CreateProveedorDto): Proveedor {
    const p: Proveedor = { id: this.idCounter++, ...dto };
    this.proveedores.push(p);
    return p;
  }

  findOne(id: number): Proveedor {
    const p = this.proveedores.find(x => x.id === id);
    if (!p) throw new NotFoundException(`Proveedor ${id} no encontrado`);
    return p;
  }
}
