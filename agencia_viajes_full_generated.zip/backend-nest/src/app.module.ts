import { Module } from '@nestjs/common';
import { DestinosModule } from './destinos/destinos.module';
import { ProveedoresModule } from './proveedores/proveedores.module';

@Module({
  imports: [ProveedoresModule, DestinosModule],
})
export class AppModule {}
