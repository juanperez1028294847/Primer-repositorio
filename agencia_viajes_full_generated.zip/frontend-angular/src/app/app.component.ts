import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Agencia de Viajes</h1>
    <app-proveedores></app-proveedores>
    <app-destinos></app-destinos>
  `
})
export class AppComponent {}
