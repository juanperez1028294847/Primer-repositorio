import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DestinosService, Destino } from '../servicios/destinos.service';
import { ProveedoresService, Proveedor } from '../servicios/proveedores.service';

@Component({
  selector: 'app-destinos',
  templateUrl: './destinos.component.html',
  styleUrls: ['./destinos.component.css']
})
export class DestinosComponent implements OnInit {
  destinos: Destino[] = [];
  proveedores: Proveedor[] = [];
  form: FormGroup;
  imagePreview: string | ArrayBuffer | null = null;
  filtroDisponibles = false;

  constructor(
    private fb: FormBuilder,
    private destinosSvc: DestinosService,
    private provSvc: ProveedoresService
  ) {
    this.form = this.fb.group({
      nombre: ['', Validators.required],
      descripcion: [''],
      precio: [0, Validators.required],
      disponible: [true],
      proveedorId: [null]
    });
  }

  ngOnInit(): void {
    this.loadAll();
    this.provSvc.list().subscribe(p => this.proveedores = p);
  }

  loadAll() {
    this.destinosSvc.list().subscribe(d => this.destinos = d);
  }

  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) {
      this.imagePreview = null;
      return;
    }
    const file = input.files[0];
    const reader = new FileReader();
    reader.onload = () => { this.imagePreview = reader.result; };
    reader.readAsDataURL(file);
  }

  submit() {
    if (this.form.invalid) return;
    this.destinosSvc.create(this.form.value).subscribe(() => {
      this.form.reset({ disponible: true, precio: 0 });
      this.imagePreview = null;
      this.loadAll();
    });
  }

  obtenerNombreProveedor(id?: number) {
    if (!id) return '-';
    const p = this.proveedores.find(x => x.id === id);
    return p ? p.nombre : 'Proveedor no encontrado';
  }
}
