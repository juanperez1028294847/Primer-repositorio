import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';

export interface Destino {
  id: number;
  nombre: string;
  descripcion?: string;
  precio: number;
  disponible: boolean;
  proveedorId?: number;
}

@Injectable({ providedIn: 'root' })
export class DestinosService {
  private base = `${environment.apiUrl}/destinos`;
  constructor(private http: HttpClient) {}

  list(): Observable<Destino[]> {
    return this.http.get<Destino[]>(this.base);
  }

  create(payload: Partial<Destino>) {
    return this.http.post<Destino>(this.base, payload);
  }

  getProveedorOfDestino(destinoId: number) {
    return this.http.get(`${this.base}/${destinoId}/proveedor`);
  }
}
