import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProveedoresService, Proveedor } from '../servicios/proveedores.service';

@Component({
  selector: 'app-proveedores',
  templateUrl: './proveedores.component.html',
  styleUrls: ['./proveedores.component.css']
})
export class ProveedoresComponent implements OnInit {
  proveedores: Proveedor[] = [];
  form: FormGroup;

  constructor(private fb: FormBuilder, private provSvc: ProveedoresService) {
    this.form = this.fb.group({
      nombre: ['', Validators.required],
      pais: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadAll();
  }

  loadAll() {
    this.provSvc.list().subscribe(p => this.proveedores = p);
  }

  submit() {
    if (this.form.invalid) return;
    this.provSvc.create(this.form.value).subscribe(() => {
      this.form.reset();
      this.loadAll();
    });
  }
}
