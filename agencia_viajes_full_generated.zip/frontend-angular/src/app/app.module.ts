import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { DestinosComponent } from './destinos/destinos.component';
import { ProveedoresComponent } from './proveedores/proveedores.component';

@NgModule({
  declarations: [AppComponent, DestinosComponent, ProveedoresComponent],
  imports: [BrowserModule, HttpClientModule, ReactiveFormsModule, FormsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
